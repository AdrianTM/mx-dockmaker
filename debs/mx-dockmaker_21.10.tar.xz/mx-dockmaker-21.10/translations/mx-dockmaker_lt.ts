<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lt">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Programos_pavadinimas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Naudojimas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Pridėti naują programą</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Komanda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="301"/>
        <source>Add application</source>
        <translation>Pridėti programą</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="395"/>
        <source>Delete this application</source>
        <translation>Ištrinti šią programą</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Fonas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="381"/>
        <source>Back</source>
        <translation>Atgal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>Failas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <location filename="../mainwindow.cpp" line="727"/>
        <location filename="../mainwindow.cpp" line="835"/>
        <location filename="../mainwindow.cpp" line="863"/>
        <source>Select icon...</source>
        <translation>Pasirinkti piktogramą...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <location filename="../mainwindow.cpp" line="93"/>
        <location filename="../mainwindow.cpp" line="693"/>
        <location filename="../mainwindow.cpp" line="731"/>
        <location filename="../mainwindow.cpp" line="838"/>
        <source>Select...</source>
        <translation>Pasirinkti...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="315"/>
        <source>Move right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="329"/>
        <source>Move left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="441"/>
        <source>Display help </source>
        <translation>Rodyti žinyną</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="444"/>
        <source>Help</source>
        <translation>Žinynas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="480"/>
        <source>About this application</source>
        <translation>Apie šią programą</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="483"/>
        <source>About...</source>
        <translation>Apie...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="490"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="522"/>
        <source>Quit application</source>
        <translation>Išeiti iš programos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="525"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="532"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="573"/>
        <source>Save</source>
        <translation>Įrašyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="580"/>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="114"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="159"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>Operation mode</source>
        <translation>Veikimo veiksena</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="162"/>
        <source>&amp;Close</source>
        <translation>&amp;Užverti</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="163"/>
        <source>&amp;Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="164"/>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>&amp;Delete</source>
        <translation>&amp;Ištrinti</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="165"/>
        <source>&amp;Edit</source>
        <translation>&amp;Taisyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <source>C&amp;reate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="311"/>
        <source>Dock name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="312"/>
        <source>Enter the name to show in the Menu:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <source>Select dock to delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>Confirmation</source>
        <translation>Patvirtinimas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Ar tikrai norite ištrinti %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Atsisakyti</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="355"/>
        <source>Next</source>
        <translation>Kitas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <source>Select dock to move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="547"/>
        <location filename="../mainwindow.cpp" line="785"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="409"/>
        <location filename="../mainwindow.cpp" line="431"/>
        <location filename="../mainwindow.cpp" line="794"/>
        <source>Could not open file</source>
        <translation>Nepavyko atverti failo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <source>Overwrite?</source>
        <translation>Perrašyti?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="547"/>
        <source>Save file</source>
        <translation>Įrašyti failą</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>Dock saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="604"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="623"/>
        <source>About %1</source>
        <translation>Apie %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="625"/>
        <source>Version: </source>
        <translation>Versija: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="626"/>
        <source>Description goes here</source>
        <translation>Čia turi būti aprašas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="628"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Autorių teisės (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="629"/>
        <source>%1 License</source>
        <translation>%1 licencija</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="638"/>
        <source>%1 Help</source>
        <translation>%1 žinynas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="766"/>
        <source>Select .desktop file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="766"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Darbalaukio failai (*.desktop)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="785"/>
        <source>Select a dock file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="788"/>
        <source>No file selected</source>
        <translation>Nepasirinktas joks failas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="788"/>
        <source>You haven&apos;t selected any dock file to edit.
Creating a new dock instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="794"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="802"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="846"/>
        <source>Select icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="846"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Piktogramos (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="../picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogas</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../about.cpp" line="32"/>
        <source>License</source>
        <translation>Licencija</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="33"/>
        <location filename="../about.cpp" line="43"/>
        <source>Changelog</source>
        <translation>Keitinių žurnalas</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="34"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>&amp;Close</source>
        <translation>&amp;Užverti</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="64"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="65"/>
        <source>You must run this program as normal user.</source>
        <translation>Privalote paleisti šią programą kaip normalus naudotojas.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="48"/>
        <source>Error</source>
        <translation type="unfinished">Klaida</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="49"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
