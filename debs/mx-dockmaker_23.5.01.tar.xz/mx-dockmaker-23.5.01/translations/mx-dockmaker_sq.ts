<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sq">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Emër_Programi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Përdorim</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Dock Preview</source>
        <translation>Paraparje Paneli</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <source>Add New Application</source>
        <translation>Shtoni Aplikacion të Ri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="298"/>
        <source>Command</source>
        <translation>Urdhër</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>Add application</source>
        <translation>Shto aplikacion</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Delete this application</source>
        <translation>Fshije këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="271"/>
        <source>Border</source>
        <translation>Anë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="264"/>
        <source>Size</source>
        <translation>Madhësi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="291"/>
        <source>Background</source>
        <translation>Sfond</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Back</source>
        <translation>Mbrapsht</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="254"/>
        <source>File</source>
        <translation>Kartelë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="387"/>
        <location filename="../mainwindow.cpp" line="779"/>
        <location filename="../mainwindow.cpp" line="893"/>
        <location filename="../mainwindow.cpp" line="928"/>
        <location filename="../mainwindow.cpp" line="952"/>
        <source>Select icon...</source>
        <translation>Përzgjidhni ikonë…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="284"/>
        <location filename="../mainwindow.cpp" line="103"/>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="783"/>
        <location filename="../mainwindow.cpp" line="896"/>
        <source>Select...</source>
        <translation>Përzgjidhni…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="102"/>
        <source>Move right</source>
        <translation>Lëvize djathtas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="116"/>
        <source>Move left</source>
        <translation>Lëvize majtas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Apply style to all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="342"/>
        <source>36x36</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="347"/>
        <source>40x40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="397"/>
        <source>Click to select different color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="503"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <source>Display help </source>
        <translation>Shfaq ndihmë </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="548"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="555"/>
        <source>Alt+H</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="584"/>
        <source>About this application</source>
        <translation>Mbi këtë aplikacion</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="587"/>
        <source>About...</source>
        <translation>Mbi…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="594"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="626"/>
        <source>Quit application</source>
        <translation>Mbylle aplikacionin</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="629"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="636"/>
        <source>Alt+N</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="677"/>
        <source>Save</source>
        <translation>Ruaje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="684"/>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="126"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Aplikacionet shtojini te paneli një nga një
2. Përzgjidhni një kartelë .desktop, ose jepni një urdhër për aplikacionin që doni
3. Përzgjidhni atribute ikone për madhësinë, sfondin (i ziu është standardi) dhe anët
4. Shtypni “Shtoje aplikacionin” që të vazhdohet, ose “Ruaje” për të përfunduar</translation>
    </message>
    <message>
        <source>black</source>
        <translation type="vanished">i zi</translation>
    </message>
    <message>
        <source>white</source>
        <translation type="vanished">i bardhë</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="172"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>Ky mjet ju lejon të krijoni një panel të ri, me një ose më tepër aplikacione. Mund të përpunoni dhe fshini gjithashtu një panel të krijuar më herët.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="175"/>
        <source>Operation mode</source>
        <translation>Mënyrë veprimi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="176"/>
        <source>&amp;Close</source>
        <translation>&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="177"/>
        <source>&amp;Move</source>
        <translation>&amp;Lëvize</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="178"/>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>&amp;Delete</source>
        <translation>&amp;Fshije</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="179"/>
        <source>&amp;Edit</source>
        <translation>&amp;Përpunoni</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="180"/>
        <source>C&amp;reate</source>
        <translation>K&amp;rijoje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>Dock name</source>
        <translation>Emër paneli</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="288"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Jepni emrin për shfaqje te Menuja:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="370"/>
        <source>Select dock to delete</source>
        <translation>Përzgjidhni panel për fshirje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>Confirmation</source>
        <translation>Ripohim</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Jeni i sigurt se doni të fshihet %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuloje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="142"/>
        <source>Next</source>
        <translation>Pasuesi</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>Select dock to move</source>
        <translation>Përzgjidhni panel për lëvizje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="371"/>
        <location filename="../mainwindow.cpp" line="395"/>
        <location filename="../mainwindow.cpp" line="576"/>
        <location filename="../mainwindow.cpp" line="841"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Kartela Panelesh (*.mxdk);;Krejt Kartelat (*.*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="405"/>
        <location filename="../mainwindow.cpp" line="429"/>
        <location filename="../mainwindow.cpp" line="851"/>
        <source>Could not open file</source>
        <translation>S&apos;u hap dot kartela</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <source>Overwrite?</source>
        <translation>Të mbishkruhet?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Doni të mbishkruhet kartela e panelit?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Save file</source>
        <translation>Ruaje kartelën</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="641"/>
        <source>Dock saved</source>
        <translation>Paneli u ruajt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="642"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>Paneli u ruajt.

Që të përpunoni panelin e krijuar rishtazi, ju lutemi, përzgjidhni “Përpunoni një panel ekzistues”.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="660"/>
        <source>About %1</source>
        <translation>Mbi %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="660"/>
        <source>MX Dockmaker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="661"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="662"/>
        <source>Description goes here</source>
        <translation>Këtu është vendi i përshkrimit</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="665"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Të drejta kopjimi (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="666"/>
        <source>%1 License</source>
        <translation>Licencë %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="675"/>
        <source>%1 Help</source>
        <translation>Ndihmë për %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="819"/>
        <source>Select .desktop file</source>
        <translation>Përzgjidhni kartelë .desktop</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="820"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Kartela Desktopi (*.desktop)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="840"/>
        <source>Select a dock file</source>
        <translation>Përzgjidhni një kartelë paneli</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="844"/>
        <source>No file selected</source>
        <translation>S’u përzgjodh kartelë</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>You haven&apos;t selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>S’keni përzgjedhur për përpunim ndonjë kartelë paneli.
Në vend të kësaj, po krijohet një panel i ri.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="852"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>S’u hap dot kartela e përzgjedhur.
Në vend të kësaj, po krijohet një panel i ri.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="860"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Aplikacionet përpunojini një nga një, duke përdorur butonat Mbrapsht dhe Pasuesi
2. Shtoni ose fshini aplikacione siç doni
3. Kur të keni mbaruar, klikoni mbi Ruaje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="934"/>
        <source>Select icon</source>
        <translation>Përzgjidhni ikonë</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="935"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Ikona (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="../picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Vendndodhje Paneli</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>Në Qendër Në Krye</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>Majtas Në Fund</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>Në Qendër Në Fund</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>Majtas Në Krye</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>Djathtas Në Krye</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>Majtas Në Qendër</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>Djathtas Në Qendër</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>Djathtas Në Fund</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>Djathta Në Krye</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>Majtas Në Krye</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>Majtas Në Fund</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>Djathtas Në Fund</translation>
    </message>
    <message>
        <location filename="../picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Përzgjidhni vendndodhje paneli</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>License</source>
        <translation type="vanished">Licencë</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Regjistër ndryshimesh</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Anuloje</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Mbylle</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Gabim</translation>
    </message>
    <message>
        <source>You must run this program as normal user.</source>
        <translation type="vanished">Këtë program duhet ta xhironi si përdorues i thjeshtë.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="41"/>
        <source>License</source>
        <translation type="unfinished">Licencë</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation type="unfinished">Regjistër ndryshimesh</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="43"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuloje</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Mbylle</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="51"/>
        <location filename="../main.cpp" line="66"/>
        <source>Error</source>
        <translation type="unfinished">Gabim</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="52"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="66"/>
        <source>You must run this program as normal user.</source>
        <translation type="unfinished">Këtë program duhet ta xhironi si përdorues i thjeshtë.</translation>
    </message>
</context>
</TS>
