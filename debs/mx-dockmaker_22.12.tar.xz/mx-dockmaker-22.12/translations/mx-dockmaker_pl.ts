<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Program_Name</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Używanie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation>Podgląd doku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Dodaj nową aplikację</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Polecenie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="311"/>
        <source>Add application</source>
        <translation>Dodaj aplikację</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="405"/>
        <source>Delete this application</source>
        <translation>Usuń tę aplikację</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation>Ramka</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Tło</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="391"/>
        <source>Back</source>
        <translation>Wstecz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <location filename="../mainwindow.cpp" line="739"/>
        <location filename="../mainwindow.cpp" line="853"/>
        <location filename="../mainwindow.cpp" line="866"/>
        <location filename="../mainwindow.cpp" line="890"/>
        <source>Select icon...</source>
        <translation>Wybierz ikonę ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <location filename="../mainwindow.cpp" line="95"/>
        <location filename="../mainwindow.cpp" line="686"/>
        <location filename="../mainwindow.cpp" line="743"/>
        <location filename="../mainwindow.cpp" line="856"/>
        <source>Select...</source>
        <translation>Wybierz...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>36x36</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="278"/>
        <source>40x40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Move right</source>
        <translation>Przesuń w prawo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="339"/>
        <source>Move left</source>
        <translation>Przesuń w lewo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="451"/>
        <source>Display help </source>
        <translation>Wyświetl pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="454"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="461"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="490"/>
        <source>About this application</source>
        <translation>O programie</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="493"/>
        <source>About...</source>
        <translation>O...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="500"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="532"/>
        <source>Quit application</source>
        <translation>Zakończ aplikację</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="535"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="542"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="590"/>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="118"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Dodawaj aplikacje do doku pojedynczo
2. Wybierz plik .desktop lub wprowadź polecenie dla danej aplikacji
3. Wybierz atrybuty ikony dla rozmiaru, tła (czarny jest standardem) i ramki
4. Naciśnij „Dodaj aplikację”, aby kontynuować lub „Zapisz”, aby zakończyć</translation>
    </message>
    <message>
        <source>black</source>
        <translation type="vanished">czarny</translation>
    </message>
    <message>
        <source>white</source>
        <translation type="vanished">biały</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>To narzędzie pozwala na utworzenie nowego doku z jedną lub kilkoma aplikacjami. Możesz także edytować lub usunąć wcześniej utworzony dok.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="164"/>
        <source>Operation mode</source>
        <translation>Tryb pracy</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="165"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <source>&amp;Move</source>
        <translation>&amp;Move</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="167"/>
        <location filename="../mainwindow.cpp" line="336"/>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edytuj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="169"/>
        <source>C&amp;reate</source>
        <translation>C&amp;reate</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Dock name</source>
        <translation>Nazwa doku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Wprowadź nazwę do wyświetlenia w menu:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="332"/>
        <source>Select dock to delete</source>
        <translation>Zaznacz dok do usunięcia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="335"/>
        <source>Confirmation</source>
        <translation>Potwierdzenie</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="335"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Czy na pewno chcesz usunąć %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="336"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="365"/>
        <source>Next</source>
        <translation>Dalej</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="361"/>
        <source>Select dock to move</source>
        <translation>Wybierz dok do przeniesienia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="333"/>
        <location filename="../mainwindow.cpp" line="362"/>
        <location filename="../mainwindow.cpp" line="543"/>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Pliki doku (*.mxdk);;Wszystkie pliki (*.*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="396"/>
        <location filename="../mainwindow.cpp" line="811"/>
        <source>Could not open file</source>
        <translation>Nie można otworzyć pliku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <source>Overwrite?</source>
        <translation>Nadpisać?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Czy chcesz nadpisać plik doku?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <source>Save file</source>
        <translation>Zapisz plik</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>Dock saved</source>
        <translation>Dok zapisany</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="609"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>Dok został zapisany.

Aby edytować nowo utworzony dok, wybierz &apos;Edytuj istniejący dok&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="627"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="627"/>
        <source>MX Dockmaker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="628"/>
        <source>Version: </source>
        <translation>Wersja:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="629"/>
        <source>Description goes here</source>
        <translation>Opis znajduje się tutaj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="632"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Prawa autorskie © MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="633"/>
        <source>%1 License</source>
        <translation>%1 Licencja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="642"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="779"/>
        <source>Select .desktop file</source>
        <translation>Wybierz plik .desktop</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="780"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Pliki pulpitu (*.desktop)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="800"/>
        <source>Select a dock file</source>
        <translation>Wybierz plik doku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="804"/>
        <source>No file selected</source>
        <translation>Nie wybrano pliku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="805"/>
        <source>You haven&apos;t selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>Nie wybrałeś żadnego pliku doku do edycji.
Zamiast tego zostanie utworzony nowy dok.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="812"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Nie można otworzyć wybranego pliku.
Zamiast tego zostanie utworzony nowy dok.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="820"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Edytuj aplikacje pojedynczo za pomocą przycisków Wstecz i Dalej
2. Dodaj lub usuń aplikacje, te które chcesz
3. Po zakończeniu kliknij Zapisz</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Select icon</source>
        <translation>Wybierz ikonę</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="873"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Ikony (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="../picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Okno dialogowe</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Położenie doku</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>Góra-Środek</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>Dół-Lewo</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>Dół-Środek</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>Góra-Lewo</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>Góra-Prawo</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>Lewo-Środek</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>Prawo-Środek</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>Dół-Prawo</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>Prawo-Góra</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>Lewo-Góra</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>Lewo-Dół</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>Prawo-Dół</translation>
    </message>
    <message>
        <location filename="../picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Wybierz położenie doku</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>License</source>
        <translation type="vanished">Licencja</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Dziennik zmian</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Anuluj</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Zamknij</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Błąd</translation>
    </message>
    <message>
        <source>You must run this program as normal user.</source>
        <translation type="vanished">Musisz uruchomić ten program jako zwykły użytkownik.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="39"/>
        <source>License</source>
        <translation type="unfinished">Licencja</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="40"/>
        <location filename="../about.cpp" line="49"/>
        <source>Changelog</source>
        <translation type="unfinished">Dziennik zmian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="41"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuluj</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="62"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Zamknij</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="51"/>
        <location filename="../main.cpp" line="66"/>
        <source>Error</source>
        <translation type="unfinished">Błąd</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="52"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="66"/>
        <source>You must run this program as normal user.</source>
        <translation type="unfinished">Musisz uruchomić ten program jako zwykły użytkownik.</translation>
    </message>
</context>
</TS>
