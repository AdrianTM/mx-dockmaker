<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Programmname</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Verwendung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Dock Preview</source>
        <translation>Dock-Vorschau</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="241"/>
        <source>Add New Application</source>
        <translation>neue Anwendung hinzufügen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="641"/>
        <source>Command</source>
        <translation>Befehl</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>Add application</source>
        <translation>Anwendung hinzufügen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Delete this application</source>
        <translation>Diese Anwendung löschen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="400"/>
        <source>Border</source>
        <translation>Rand</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="664"/>
        <source>Background</source>
        <translation>Hintergrund</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="198"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="465"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="504"/>
        <location filename="../mainwindow.cpp" line="797"/>
        <location filename="../mainwindow.cpp" line="913"/>
        <location filename="../mainwindow.cpp" line="949"/>
        <location filename="../mainwindow.cpp" line="973"/>
        <source>Select icon...</source>
        <translation>Symbol auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="677"/>
        <location filename="../mainwindow.cpp" line="100"/>
        <location filename="../mainwindow.cpp" line="741"/>
        <location filename="../mainwindow.cpp" line="801"/>
        <location filename="../mainwindow.cpp" line="916"/>
        <source>Select...</source>
        <translation>Auswählen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="132"/>
        <source>Move right</source>
        <translation>Nach rechts verschieben</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="146"/>
        <source>Move left</source>
        <translation>Nach links verschieben</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <location filename="../mainwindow.ui" line="338"/>
        <location filename="../mainwindow.ui" line="514"/>
        <location filename="../mainwindow.ui" line="579"/>
        <source>Click to select different color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="407"/>
        <source>Apply style to all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="414"/>
        <source>Hover Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="442"/>
        <source>36x36</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="447"/>
        <source>40x40</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="491"/>
        <source>Hover Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="716"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="719"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="726"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="755"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="758"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="765"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="797"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="800"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="807"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="848"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="855"/>
        <source>Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="123"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Anwendungen nacheinander zum Dock hinzufügen
2. Wählen sie eine .desktop-Datei aus oder geben sie einen Befehl für die gewünschte Anwendung ein
3. Wählen sie Symbol-Attribute für Größe, Hintergrund (schwarz ist Standard) und Rahmen
4. Drücken sie &quot;Anwendung hinzufügen&quot;, um fortzufahren, oder &quot;Speichern&quot;, um zu beenden.</translation>
    </message>
    <message>
        <source>black</source>
        <translation type="vanished">schwarz</translation>
    </message>
    <message>
        <source>white</source>
        <translation type="vanished">weiß</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="160"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>Mit diesem Tool können sie ein neues Dock mit einer oder mehreren Anwendungen erstellen. Sie können auch ein zuvor erstelltes Dock bearbeiten oder löschen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="163"/>
        <source>Operation mode</source>
        <translation>Betriebsmodus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="164"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="165"/>
        <source>&amp;Move</source>
        <translation>&amp;Verschieben</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="166"/>
        <location filename="../mainwindow.cpp" line="375"/>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="167"/>
        <source>&amp;Edit</source>
        <translation>&amp;Bearbeiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>C&amp;reate</source>
        <translation>E&amp;rstellen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="276"/>
        <source>Dock name</source>
        <translation>Name des Docks</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="276"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Geben sie den Namen ein, der im Menü angezeigt werden soll:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="371"/>
        <source>Select dock to delete</source>
        <translation>Wählen sie das zu löschende Dock aus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>Confirmation</source>
        <translation>Bestätigung</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="374"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Sind sie sicher, dass sie %1 löschen möchten?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="375"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="172"/>
        <source>Next</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="395"/>
        <source>Select dock to move</source>
        <translation>Wählen sie das zu verschiebende Dock aus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="396"/>
        <location filename="../mainwindow.cpp" line="596"/>
        <location filename="../mainwindow.cpp" line="861"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Dock-Dateien (*.mxdk);;Alle Dateien (*.*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="430"/>
        <location filename="../mainwindow.cpp" line="871"/>
        <source>Could not open file</source>
        <translation>Datei konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Overwrite?</source>
        <translation>Überschreiben?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Möchten sie die Dock-Datei überschreiben?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="595"/>
        <source>Save file</source>
        <translation>Datei speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="663"/>
        <source>Dock saved</source>
        <translation>Dock gespeichert</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="664"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>Das Dock wurde gespeichert

Um das neu erstellte Dock zu bearbeiten, wählen sie bitte &apos;Ein vorhandenes Dock bearbeiten&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <source>MX Dockmaker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="683"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="684"/>
        <source>Description goes here</source>
        <translation>Geben sie hier die Beschreibung ein</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="687"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="688"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="697"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="839"/>
        <source>Select .desktop file</source>
        <translation>.desktop-Datei auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="840"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Arbeitsoberflächendateien (*.desktop)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="860"/>
        <source>Select a dock file</source>
        <translation>Eine Dock-Datei auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="864"/>
        <source>No file selected</source>
        <translation>Es wurde keine Datei ausgewählt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="865"/>
        <source>You haven&apos;t selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>Sie haben keine Dock-Datei ausgewählt
Erstellen sie stattdessen eine neue Dock-Datei.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Ausgewählte Datei konnte nicht geöffnet werden.
Stattdessen wurde ein neues Dock erstellt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="880"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Bearbeiten sie die Anwendungen nacheinander mit den Schaltflächen Zurück und Weiter.
2. Anwendungen nach Belieben hinzufügen oder löschen
3. Wenn sie fertig sind, klicken sie auf Speichern.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="955"/>
        <source>Select icon</source>
        <translation>Symbol auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="956"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Symbole (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="../picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Speicherort Dock</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>ObenMitte</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>UntenLinks</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>UntenMitte</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>ObenLinks</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>ObenRechts</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>LinksMitte</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>RechtsMitte</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>UntenRechts</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>RechtsOben</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>LinksOben</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>LinksUnten</translation>
    </message>
    <message>
        <location filename="../picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>RechtsUnten</translation>
    </message>
    <message>
        <location filename="../picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Den Speicherort der Dock-Datei auswählen</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>License</source>
        <translation type="vanished">Lizenz</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Änderungsprotokoll</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Abbrechen</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Schließen</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Fehler</translation>
    </message>
    <message>
        <source>You must run this program as normal user.</source>
        <translation type="vanished">Diese Anwendung muss als normaler Benutzer ausgeführt werden.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="41"/>
        <source>License</source>
        <translation type="unfinished">Lizenz</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="42"/>
        <location filename="../about.cpp" line="51"/>
        <source>Changelog</source>
        <translation type="unfinished">Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="43"/>
        <source>Cancel</source>
        <translation type="unfinished">Abbrechen</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="51"/>
        <location filename="../main.cpp" line="66"/>
        <source>Error</source>
        <translation type="unfinished">Fehler</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="52"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.cpp" line="66"/>
        <source>You must run this program as normal user.</source>
        <translation type="unfinished">Diese Anwendung muss als normaler Benutzer ausgeführt werden.</translation>
    </message>
</context>
</TS>
