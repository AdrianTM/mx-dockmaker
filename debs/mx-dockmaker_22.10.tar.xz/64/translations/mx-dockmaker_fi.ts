<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="fi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Ohjelman_Nimi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Käyttö</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation>Telakan esikatselu</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Lisää uusi sovellus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Käsky</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>Add application</source>
        <translation>Lisää sovellus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="393"/>
        <source>Delete this application</source>
        <translation>Poista tämä sovellus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation>Raja</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Taustakuva</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="379"/>
        <source>Back</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>Tiedosto</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="216"/>
        <location filename="mainwindow.cpp" line="708"/>
        <location filename="mainwindow.cpp" line="735"/>
        <source>Select icon...</source>
        <translation>Valitse kuvake...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="229"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="582"/>
        <location filename="mainwindow.cpp" line="711"/>
        <source>Select...</source>
        <translation>Valitse...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="315"/>
        <source>Move right</source>
        <translation>Siirrä oikealle</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="328"/>
        <source>Move left</source>
        <translation>Siirrä vasemmalle</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="439"/>
        <source>Display help </source>
        <translation>Näytä ohje</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="442"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>About this application</source>
        <translation>Tietoja tästä sovelluksesta</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="481"/>
        <source>About...</source>
        <translation>Tietoja...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="488"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="520"/>
        <source>Quit application</source>
        <translation>Lopeta sovellus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="523"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="530"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="571"/>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="103"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Lisää sovellukset telakkaan yksi kerrallaan
2. Valitse muodon .desktop tiedosto tai syötä käsky halutulle ohjelmalle
3. Valitse kuvakkeen määritykset koolle, taustalle (musta on oletuksena) sekä kehysrajaukselle
4. Paina &quot;lisää sovellus&quot; jatkaaksesi tai &quot;tallenna&quot; viimeistelläksesi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="126"/>
        <location filename="mainwindow.cpp" line="590"/>
        <source>black</source>
        <translation>musta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <location filename="mainwindow.cpp" line="591"/>
        <source>white</source>
        <translation>valkoinen</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="137"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>Tämä työkalu tarjoaa uuden telakan luomisen yhden tai useamman sovelluksen kanssa. Voit myös muokata tai poistaa aiemmin luodun telakan.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Operation mode</source>
        <translation>Toimintotila</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="141"/>
        <source>&amp;Move</source>
        <translation>&amp;Siirrä</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="142"/>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Delete</source>
        <translation>&amp;Poista</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>&amp;Edit</source>
        <translation>&amp;Muokkaa</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="144"/>
        <source>C&amp;reate</source>
        <translation>&amp;Luo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="220"/>
        <source>Dock name</source>
        <translation>Telakan nimi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Syötä päävalikossa näytettävä nimi:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <source>Select dock to delete</source>
        <translation>Valitse poistettava telakka</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="294"/>
        <source>Confirmation</source>
        <translation>Vahvistus</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Oletko varma että haluat poistaa kohteen %1?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Keskeytä</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="353"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="320"/>
        <source>Select dock to move</source>
        <translation>Valitse siirrettävä telakka</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="320"/>
        <location filename="mainwindow.cpp" line="454"/>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Telakan tiedostot (*.mxdk);;Kaikki tiedostot (*.*)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="330"/>
        <location filename="mainwindow.cpp" line="351"/>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open file</source>
        <translation>Tiedostoa ei voitu avata</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Overwrite?</source>
        <translation>Ylikirjoita?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Haluatko ylikirjoittaa telakkatiedoston?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="454"/>
        <source>Save file</source>
        <translation>Tallenna tiedosto</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>Dock saved</source>
        <translation>Telakka tallennettu</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>Telakka on tallennettu.

Muokataksesi äskettäin luotua telakkaa valitse &apos;muokkaa olemassaolevaa telakkaa&apos;.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="511"/>
        <source>About %1</source>
        <translation>%1 lisätietoja</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>Version: </source>
        <translation>Versio: </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="514"/>
        <source>Description goes here</source>
        <translation>Kuvaus tulee tähän</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="516"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="517"/>
        <source>%1 License</source>
        <translation>%1 lupa</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="526"/>
        <source>%1 Help</source>
        <translation>%1 Apuopas</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Select .desktop file</source>
        <translation>Valitse tiedosto muotoa .desktop</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Työpöytätiedostot (*.desktop)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Select a dock file</source>
        <translation>Valitse telakkatiedosto</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>No file selected</source>
        <translation>Tiedostoa ei valittu</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>You haven't selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>Et ole valinnut yhtäkään telakkatiedostoa muokattavaksi.
Luodaan sen sijasta uusi telakka.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Valittua tiedostoa ei voitu avata.
Luodaan sen sijasta uusi telakka.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="675"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Muokkaa sovelluksia yksi kerrallaan käyttäen Takaisin- ja Seuraava-painikkeita
2. Lisää tai poista sovelluksia kuten haluat
3. Kun olet saanut kaiken päätökseen napsauta Tallenna</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Select icon</source>
        <translation>Valitse kuvake</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Kuvakkeet (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Vuoropuhelu</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Telakan sijainti</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>Ylhäällä keskellä</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>Alavasemmalla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>Alhaalla keskellä</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>Ylävasemmalla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>Yläoikealla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>Keskivasemmalla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>Keskioikealla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>Alaoikealla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>Yläoikealla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>Ylävasemmalla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>Alavasemmalla</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>Alaoikealla</translation>
    </message>
    <message>
        <location filename="picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Valitse telakan sijainti</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="about.cpp" line="32"/>
        <source>License</source>
        <translation>Lisenssi</translation>
    </message>
    <message>
        <location filename="about.cpp" line="33"/>
        <location filename="about.cpp" line="43"/>
        <source>Changelog</source>
        <translation>Muutosloki</translation>
    </message>
    <message>
        <location filename="about.cpp" line="34"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="about.cpp" line="51"/>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <location filename="main.cpp" line="57"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="main.cpp" line="58"/>
        <source>You must run this program as normal user.</source>
        <translation>Sinun täytyy suorittaa tämä ohjelma tavallisena käyttäjänä.</translation>
    </message>
</context>
</TS>