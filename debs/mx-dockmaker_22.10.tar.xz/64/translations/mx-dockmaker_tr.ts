<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="tr">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Program_Adı</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Kullanım</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation>Panel Önizleme</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Yeni Uygulama Ekle</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Komut</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>Add application</source>
        <translation>Uygulama ekle</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="393"/>
        <source>Delete this application</source>
        <translation>Bu uygulamayı sil</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation>Sınır</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Arkaplan</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="379"/>
        <source>Back</source>
        <translation>Geri</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>Dosya</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="216"/>
        <location filename="mainwindow.cpp" line="708"/>
        <location filename="mainwindow.cpp" line="735"/>
        <source>Select icon...</source>
        <translation>Simge seçin...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="229"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="582"/>
        <location filename="mainwindow.cpp" line="711"/>
        <source>Select...</source>
        <translation>Seç...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="315"/>
        <source>Move right</source>
        <translation>Sağa taşı</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="328"/>
        <source>Move left</source>
        <translation>Sola taşı</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="439"/>
        <source>Display help </source>
        <translation>Yardımı görüntüle</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="442"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>About this application</source>
        <translation>Uygulama hakkında</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="481"/>
        <source>About...</source>
        <translation>Hakkında...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="488"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="520"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="523"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="530"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="571"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="103"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Panele birer birer uygulama ekleyin
2. Bir .desktop dosyası seçin veya istediğiniz uygulama için bir komut girin
3. Boyut, arka plan (siyah standarttır) ve kenar için simge özniteliklerini seçin
4. Devam etmek için &quot;Uygulama ekle&quot;ye bitirmek için &quot;Kaydet&quot;e basın</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="126"/>
        <location filename="mainwindow.cpp" line="590"/>
        <source>black</source>
        <translation>siyah</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <location filename="mainwindow.cpp" line="591"/>
        <source>white</source>
        <translation>beyaz</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="137"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>Bu araç, bir veya daha fazla uygulama ile yeni bir panel oluşturmanıza olanak sağlar. Ayrıca daha önce oluşturulmuş bir paneli düzenleyebilir veya silebilirsiniz.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Operation mode</source>
        <translation>İşlem kipi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="141"/>
        <source>&amp;Move</source>
        <translation>Taşı</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="142"/>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Delete</source>
        <translation>&amp;Sil</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="144"/>
        <source>C&amp;reate</source>
        <translation>Oluştur</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="220"/>
        <source>Dock name</source>
        <translation>Panel adı</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Menüde gösterilecek adı girin:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <source>Select dock to delete</source>
        <translation>Silinecek paneli seç</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="294"/>
        <source>Confirmation</source>
        <translation>Onay</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>%1&apos;i silmek istediğinizden emin misiniz?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Cancel</source>
        <translation>&amp;İptal</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="353"/>
        <source>Next</source>
        <translation>Sonraki</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="320"/>
        <source>Select dock to move</source>
        <translation>Taşınacak paneli seç</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="320"/>
        <location filename="mainwindow.cpp" line="454"/>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Panel Dosyaları (*.mxdk);;Tüm dosyalar (*.*)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="330"/>
        <location filename="mainwindow.cpp" line="351"/>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open file</source>
        <translation>Dosya açılamadı</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Overwrite?</source>
        <translation>Üstüne yazılsın mı?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation>Panel dosyasının üzerine yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="454"/>
        <source>Save file</source>
        <translation>Dosyayı kaydet</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>Dock saved</source>
        <translation>Panel kaydedildi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>Panel kaydedildi.

Yeni oluşturulan paneli düzenlemek için lütfen &apos;Mevcut bir paneli düzenle&apos;yi seçin.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="511"/>
        <source>About %1</source>
        <translation>Hakkında %1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>Version: </source>
        <translation>Sürüm:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="514"/>
        <source>Description goes here</source>
        <translation>Açıklama buraya</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="516"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Telif Hakkı (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="517"/>
        <source>%1 License</source>
        <translation>%1 Telif Hakkı</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="526"/>
        <source>%1 Help</source>
        <translation>%1 Yardım</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Select .desktop file</source>
        <translation>.desktop dosyasını seçin</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Masaüstü Dosyaları (*.desktop)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Select a dock file</source>
        <translation>Bir panel dosyası seçin</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>No file selected</source>
        <translation>Seçilmiş dosya yok</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>You haven't selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>Düzenlemek için herhangi bir panel dosyası seçmediniz.
Bunun yerine yeni bir panel oluşturun.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Seçilen dosya açılamıyor.
Bunun yerine yeni bir panel oluşturun.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="675"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Geri ve İleri düğmelerini kullanarak uygulamaları birer birer düzenleyin
2. Uygulamaları istediğiniz gibi ekleyin veya silin
3. Bittiğinde Kaydeti tıklayın</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Select icon</source>
        <translation>Simge seçin</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Simgeler (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Panel Konumu</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>Üst Orta</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>Alt Sol</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>Alt Orta</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>Üst Sol</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>Üst Sağ</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>Sol Orta</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>Sağ Orta</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>Alt Sağ</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>Sağ Üst</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>Sol Üst</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>Sol Alt</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>Sağ Alt</translation>
    </message>
    <message>
        <location filename="picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Panel konumunu seçin</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="about.cpp" line="32"/>
        <source>License</source>
        <translation>Ruhsat</translation>
    </message>
    <message>
        <location filename="about.cpp" line="33"/>
        <location filename="about.cpp" line="43"/>
        <source>Changelog</source>
        <translation>Değişim günlüğü</translation>
    </message>
    <message>
        <location filename="about.cpp" line="34"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="about.cpp" line="51"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="main.cpp" line="57"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="main.cpp" line="58"/>
        <source>You must run this program as normal user.</source>
        <translation>Bu programı normal kullanıcı olarak çalıştırmalısınız.</translation>
    </message>
</context>
</TS>