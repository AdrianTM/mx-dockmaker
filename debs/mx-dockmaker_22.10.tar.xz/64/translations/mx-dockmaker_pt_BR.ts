<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="pt_BR">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Nome_do_Programa</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="29"/>
        <source>Usage</source>
        <translation>Uso</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="106"/>
        <source>Dock Preview</source>
        <translation>Visualizar a Doca</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="118"/>
        <source>Add New Application</source>
        <translation>Adicionar Novo Aplicativo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Command</source>
        <translation>Comando</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="301"/>
        <source>Add application</source>
        <translation>Adicionar Aplicativo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="393"/>
        <source>Delete this application</source>
        <translation>Eliminar este aplicativo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Border</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="154"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="161"/>
        <source>Background</source>
        <translation>Tela de fundo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="379"/>
        <source>Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="184"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="216"/>
        <location filename="mainwindow.cpp" line="708"/>
        <location filename="mainwindow.cpp" line="735"/>
        <source>Select icon...</source>
        <translation>Selecionar o ícone ...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="229"/>
        <location filename="mainwindow.cpp" line="82"/>
        <location filename="mainwindow.cpp" line="582"/>
        <location filename="mainwindow.cpp" line="711"/>
        <source>Select...</source>
        <translation>Selecionar ...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="315"/>
        <source>Move right</source>
        <translation>Mover para a direita</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="328"/>
        <source>Move left</source>
        <translation>Mover para a esquerda</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="439"/>
        <source>Display help </source>
        <translation>Exibir ajuda</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="442"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="449"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="478"/>
        <source>About this application</source>
        <translation>Sobre este aplicativo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="481"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="488"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="520"/>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="523"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="530"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="571"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="103"/>
        <source>1. Add applications to the dock one at a time
2. Select a .desktop file or enter a command for the application you want
3. Select icon attributes for size, background (black is standard) and border
4. Press &quot;Add application&quot; to continue or &quot;Save&quot; to finish</source>
        <translation>1. Adicione os aplicativos à doca (dock), um de cada vez
2. Selecione um arquivo .desktop ou insera um comando para o aplicativo que você quer adicionar
3. Selecione os atributos do ícone para o tamanho, o fundo (a cor preta é o padrão) e a borda
4. Pressione a opção &quot;Adicionar Aplicativo&quot; para continuar ou &quot;Salvar&quot; para finalizar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="126"/>
        <location filename="mainwindow.cpp" line="590"/>
        <source>black</source>
        <translation>preto</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="127"/>
        <location filename="mainwindow.cpp" line="591"/>
        <source>white</source>
        <translation>branco</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="137"/>
        <source>This tool allows you to create a new dock with one or more applications. You can also edit or delete a dock created earlier.</source>
        <translation>Esta ferramenta possibilita a criação de novas docas com um ou mais aplicativos. Também possibilita editar ou eliminar uma doca existente.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="139"/>
        <source>Operation mode</source>
        <translation>Modo de operação</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="141"/>
        <source>&amp;Move</source>
        <translation>&amp;Mover</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="142"/>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="144"/>
        <source>C&amp;reate</source>
        <translation>&amp;Criar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="220"/>
        <source>Dock name</source>
        <translation>Nome da doca</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Enter the name to show in the Menu:</source>
        <translation>Inserir o nome a ser exibido no Menu:</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <source>Select dock to delete</source>
        <translation>Selecionar a doca para ser excluída</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="294"/>
        <source>Confirmation</source>
        <translation>Confirmação</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Você tem certeza que quer excluir %1?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="295"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="353"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="320"/>
        <source>Select dock to move</source>
        <translation>Selecionar a doca para ser movimentada</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="293"/>
        <location filename="mainwindow.cpp" line="320"/>
        <location filename="mainwindow.cpp" line="454"/>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Dock Files (*.mxdk);;All Files (*.*)</source>
        <translation>Arquivos de Docas (* .mxdk);; Todos os Arquivos (*. *)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="330"/>
        <location filename="mainwindow.cpp" line="351"/>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open file</source>
        <translation>Não foi possível abrir o arquivo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Overwrite?</source>
        <translation> Sobrescrever?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="453"/>
        <source>Do you want to overwrite the dock file?</source>
        <translation> Sobrescrever o arquivo da doca?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="454"/>
        <source>Save file</source>
        <translation>Salvar o arquivo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>Dock saved</source>
        <translation>A doca foi salva</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="492"/>
        <source>The dock has been saved.

To edit the newly created dock please select &apos;Edit an existing dock&apos;.</source>
        <translation>A doca foi salva.

Para editar a doca criada, selecionar &apos;Editar uma doca existente&apos;.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="511"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="514"/>
        <source>Description goes here</source>
        <translation>Inserir aqui a descrição</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="516"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="517"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="526"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Select .desktop file</source>
        <translation>Selecionar o arquivo .desktop</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="638"/>
        <source>Desktop Files (*.desktop)</source>
        <translation>Arquivos da Área de Trabalho (*.desktop)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="657"/>
        <source>Select a dock file</source>
        <translation>Selecionar um arquivo de doca</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>No file selected</source>
        <translation>Nenhum arquivo foi selecionado</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="660"/>
        <source>You haven't selected any dock file to edit.
Creating a new dock instead.</source>
        <translation>Você não selecionou nenhum arquivo de doca para editar.
Criando uma nova doca em seu lugar.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="666"/>
        <source>Could not open selected file.
Creating a new dock instead.</source>
        <translation>Não foi possível abrir o arquivo selecionado.
Criando uma nova doca em seu lugar.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="675"/>
        <source>1. Edit applications one at a time using the Back and Next buttons
2. Add or delete applications as you like
3. When finished click Save</source>
        <translation>1. Edite os aplicativos um de cada vez utilizando os botões &apos;Voltar&apos; e &apos;Avançar&apos;
2. Adicione ou exclua os aplicativos como você quiser
3. Quando você concluir, clique no botão &apos;Salvar&apos;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Select icon</source>
        <translation>Selecionar o ícone</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="719"/>
        <source>Icons (*.png *.jpg *.bmp *.xpm *.svg)</source>
        <translation>Ícones (*.png *.jpg *.bmp *.xpm *.svg)</translation>
    </message>
</context>
<context>
    <name>PickLocation</name>
    <message>
        <location filename="picklocation.ui" line="14"/>
        <source>Dialog</source>
        <translation>Caixa de diálogo</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="23"/>
        <source>Dock Location</source>
        <translation>Posicionamento da Doca</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="29"/>
        <source>TopCenter</source>
        <translation>Em cima, ao centro</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="45"/>
        <source>BottomLeft</source>
        <translation>Embaixo, à esquerda</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="61"/>
        <source>BottomCenter</source>
        <translation>Embaixo, ao centro</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="80"/>
        <source>TopLeft</source>
        <translation>Em cima, à esquerda</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="96"/>
        <source>TopRight</source>
        <translation>Em cima, à direita</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="112"/>
        <source>LeftCenter</source>
        <translation>À esquerda, ao centro</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="128"/>
        <source>RightCenter</source>
        <translation>À direita, ao centro</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="144"/>
        <source>BottomRight</source>
        <translation>Embaixo, à direita</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="160"/>
        <source>RightTop</source>
        <translation>À direita, em cima</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="173"/>
        <source>LeftTop</source>
        <translation>À esquerda, em cima</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="189"/>
        <source>LeftBottom</source>
        <translation>À esquerda, embaixo</translation>
    </message>
    <message>
        <location filename="picklocation.ui" line="205"/>
        <source>RightBottom</source>
        <translation>À direita, embaixo</translation>
    </message>
    <message>
        <location filename="picklocation.cpp" line="9"/>
        <source>Select dock location</source>
        <translation>Selecionar a posição da doca</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="about.cpp" line="32"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="about.cpp" line="33"/>
        <location filename="about.cpp" line="43"/>
        <source>Changelog</source>
        <translation>Relatório de alterações</translation>
    </message>
    <message>
        <location filename="about.cpp" line="34"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="about.cpp" line="51"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="main.cpp" line="57"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="main.cpp" line="58"/>
        <source>You must run this program as normal user.</source>
        <translation>Você deve executar este programa como um usuário normal.</translation>
    </message>
</context>
</TS>